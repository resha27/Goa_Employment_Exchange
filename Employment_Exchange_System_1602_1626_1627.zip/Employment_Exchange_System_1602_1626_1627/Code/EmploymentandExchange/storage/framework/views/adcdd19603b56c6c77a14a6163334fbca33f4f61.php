<html>
	<head>
		<title>View Jobseeker</title>
		<meta charset="UTF-8" />
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
       <!-- <link rel="stylesheet" href="<?php echo e(asset('css/employment/view.css')); ?>" />-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="../css/AdminLTE.min.css">
        <link rel="stylesheet" href="../css/_all-skins.min.css">
        <link rel="stylesheet" href="../css/custom.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
        </head>
	<body class="hold-transition skin-green sidebar-mini">
        <header class="main-header">
            <a href="index.php" class="logo logo-bg">
                <span class="logo-mini"><b>J</b>P</span>
                <span class="logo-lg"><b>Company</b> Dashboard</span>
            </a>
            <nav class="navbar navbar-static-top">
                <div class="navbar-custom-menu">
                    <ul class="nav navbar-nav">
                            <li><a href="/company"><i class="fa fa-arrow-circle-o-right"></i> Logout</a></li>           
                    </ul>
                </div>
            </nav>
        </header>
   
		<div class="container">

<table class="table table-striped">
        <thead>
          <tr>
                <th >Email</th>
                <th >FullName</th>
                <th >Gender</th>
                <th >Birth Date</th>
                <th >Contact</th>
                <th >Qualification</th>
                <th >SSC Marksheet</th>
                <th >HSSC Stream</th>
                <th >HSSC Marksheet</th>
                <th >Graduation</th>
                <th >Graduation Marksheet</th>
                <th >PostGraduation</th>
                <th >PostGraduation Marksheet</th>
          </tr>
        </thead>
        <tbody>
                <?php $__currentLoopData = $jobseekerdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seeker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                     <td><?php echo e($seeker->email); ?></td> 
                <td><?php echo e($seeker->fullname); ?></td>
                   <td><?php echo e($seeker->gender); ?></td>
                   <td><?php echo e($seeker->dob); ?></td>
                   <td><?php echo e($seeker->contact); ?></td>
                   <td><?php echo e($seeker->qualifications); ?></td>
                   <td><?php echo e($seeker->fileupload); ?></td>
                   <td><?php echo e($seeker->hssc); ?></td>
                   <td><?php echo e($seeker->fileupload2); ?></td>
                   <td><?php echo e($seeker->graduation); ?></td>
                   <td><?php echo e($seeker->fileupload3); ?></td>
                   <td><?php echo e($seeker->postgraduation); ?></td>
                   <td><?php echo e($seeker->fileupload4); ?></td>
             </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
        </tbody>
      </table>
</div>	

 <footer class="main-footer" style="margin-left: 0px;">
            <div class="text-center">
                <strong>Copyright &copy; 2017-2018 <a href="learningfromscratch.online">Employment Exchange</a>.</strong> All rights
            reserved.
            </div>
        </footer>
        <div class="control-sidebar-bg"></div>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script src="../js/adminlte.min.js"></script>
		
	</body>
</html>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Goa-State Employment Exchange</title>

    <link rel="stylesheet" href="<?php echo e(asset('css/employment/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/employment/bootstrap.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/employment/contact.css')); ?>" />
   
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <style>
        body {
            background-image: url('https://goodfellowcoaching.com/wp-content/uploads/2017/05/contact-bg@2x.jpg');
        }
    </style>

  </head>

  <body>

  
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark ">
      <div class="container">
        <a class="navbar-brand" href="#">Goa Employment Exchange</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
          <li class="nav-item">
              <a class="nav-link" href="http://localhost:8000/about">Aboutus</a>
            </li>
           
            <li class="nav-item">
              <a class="nav-link" href="http://localhost:8000/contact">Contact</a>
            </li>
			 <li class="nav-item">
              <a class="nav-link" href="http://localhost:8000/jobseeker/jlogin">JobseekerLogin</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="http://localhost:8000/company/clogin">CompanyLogin</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="http://localhost:8000/abc">Register</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

 
    <div class="container">
      <div class="row">
        <div class="col-lg-12 text-center">
          <h1 class="mt-5">Contact Us </h1>
			<h5>For North Goa</h2>
			<p class="lead">
				Commissioner, labour and employment,</br>
				4th floor, Shramshakti Bhavan, Patto Plaza,</br>
				Panjim, Goa - 403001</br>
				Telephone: 2437081, 2437082</br>
			<p>
			<h5>For South Goa</h5>
			<p class="lead">
				Pioneers Complex, old market, </br>
				opposite district & sessions court,</br>
				Margao, Goa - 403601</br>
				Telephone: 2706021</br>
			</p>
        </div>
      </div>
    </div>
    <footer>
		<div class="footer">
			<p>Copyright @Employment  Exchange 2018-2019.</p>
		 </div>
	</footer>
    
   

  </body>

</html>

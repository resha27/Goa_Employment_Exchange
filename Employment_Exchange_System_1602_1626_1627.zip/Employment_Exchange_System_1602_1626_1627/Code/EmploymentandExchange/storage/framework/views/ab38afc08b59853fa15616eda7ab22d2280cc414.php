<!DOCTYPE html>

<html>
<head>
    <meta charset="utf-8">
    <title>Jobseeker Login Form</title>

    <link rel="stylesheet" href="<?php echo e(asset('css/employment/StyleSheet1.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('css/employment/bootstrap.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/employment/main.css')); ?>" />
    <link href="css/employment/main.css" rel="stylesheet" />
    <link href="css/employment/bootstrap.min.css" rel="stylesheet" />

    <style>
        body {
            background-image: url('https://www.theclydehotel.com.au/wp-content/uploads/2014/11/bg-pd-2.jpg');
        }
    </style>

</head>
<body>
<?php if(Session::has('flash_message_error')): ?>
            
            <div class="alert alert-success alert-block">
           <button type="button" class="close" data-dismiss="alert">×</button>	
           <strong><?php echo session('flash_message_error'); ?></strong>
   </div> 
   <?php endif; ?>
   <?php if(Session::has('flash_message_success')): ?>
               
               <div class="alert alert-success alert-block">
              <button type="button" class="close" data-dismiss="alert">×</button>	
              <strong><?php echo session('flash_message_success'); ?></strong>
      </div> 
      <?php endif; ?>
    <header>
        <!-- Navigation -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
            <div class="container">
                <a class="navbar-brand" href="#">Goa Employment Exchange</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="http://localhost:8000/about">Aboutus</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="http://localhost:8000/contact">Contact</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="http://localhost:8000/jobseeker/jlogin">JobseekerLogin</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="http://localhost:8000/company/clogin">CompanyLogin</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="http://localhost:8000/abc">Register</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <div class="loginBox">

        <h2>Job Seeker Login</h2>
        <form method="POST" action="<?php echo e(url('jobseeker')); ?>"><?php echo e(csrf_field()); ?>

            <p>Email</p>
            <input type="email" name="email" placeholder="Enter Email">
            <p>Password</p>
            <input type="password" name="password" placeholder="••••••">
            <input type="submit" name="signin" value="Sign In">

        </form>
    </div>

<footer>
		<div class="footer">
			<p>Copyright @Employment  Exchange 2018-2019.</p>
		 </div>
	</footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>

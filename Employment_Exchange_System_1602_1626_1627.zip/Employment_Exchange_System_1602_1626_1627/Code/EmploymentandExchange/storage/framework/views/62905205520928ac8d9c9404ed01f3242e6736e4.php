<!DOCTYPE html>
<html>    
    <head>
		<title>Add Job</title>
        <link rel="stylesheet" href="../css/addjob.css" />
    </head>
	<body>
        <header>
            <div class="head">
                <p>Company Dashboard</p>
            </div>
        </header>
                
        <form method="post" action="<?php echo e(url('/company/addjob')); ?>">
            <div class="container">
                <div id="title"><h2>ADD JOB DETAILS</h2></div>
                <?php echo e(csrf_field()); ?>


                <div class="left-content"><label for="rollno">Job Designation :</label></div>
                <div class="right-content"><input type="text" name="jobdesignation" placeholder="Example. Mechanic" required></div>

                <div class="left-content"><label for="Minimum Qualification:">Minimum Qualification :</label></div>
                <div class="right-content"><input type="text" name="minqual" placeholder="Example. Graduate" required></div>

                <div class="left-content"><label for="experience">Experience(in years) :</label></div>
                <div class="right-content"><input type="text" name="experience" placeholder="Example. 5" required></div>

                <div class="left-content"><label for="jobdetails">Job Details :</label></div>
                <div class="right-content"><textarea name="jobdetails" placeholder="Example. Worked as Mechanic.." rows="7" cols="47" required></textarea>

                <div class="left-content"><label for="salary">Salary :</label></div>
                <div class="right-content"><input type="text" name="salary" placeholder="Example. INR 5000" required></div>
        
                <div id="btn">
                    <button class="button submit">Submit</button>
                    <button class="button reset" value="reset" type="reset">Reset</button>
                </div>
            </div>
        </form>
        <footer>
            <div class="foot">
                <p>Copyright &copy; Goa Employment Exchange 2018</p>
            </div>
        </footer>
    </body>
</html>
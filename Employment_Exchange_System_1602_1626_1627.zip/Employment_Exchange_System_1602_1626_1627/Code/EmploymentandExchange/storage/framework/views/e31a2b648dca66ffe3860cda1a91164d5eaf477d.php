<?php $__env->startSection('content'); ?>
<div class="container">
        
        <div id="myCarousel" class="carousel slide" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                <li data-target="#myCarousel" data-slide-to="1"></li>
                <li data-target="#myCarousel" data-slide-to="2"></li>
            </ol>

            <!-- Wrapper for slides -->
            <div class="carousel-inner">
                <div class="item active">
                    <img src="css/images/20170130170703-GettyImages-539953664.jpeg" style="width:10000px; height:400px;" />
                </div>

                <div class="item">
                    <img src="css/images/how-to-register-a-company-in-India.jpg" style="width:10000px; height:400px;" />
                </div>

                <div class="item">
                   
                    <img src="css/images/20170130170703-GettyImages-539953664.jpeg" style="width:10000px;height:400px;"  />
                </div>
            </div>

            <!-- Left and right controls -->
            <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                <span class="glyphicon glyphicon-chevron-left"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control" href="#myCarousel" data-slide="next">
                <span class="glyphicon glyphicon-chevron-right"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>


    <!-- Page Content -->
    <div class="container">
      <div class="row">
        <div class="col-lg-12 text-center"><br/><br/><br/>
			<h1 class="welcome">Welcome to the department of employment exchange Goa</h1>
			<h3 class="about">About the department of employment exchange Goa</h3><br/>
			<p class="lead" font-size:80px>
				&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp The department administers the Employment Exchanges (Compulsory Notification of Vacancies) Act, 1959, 
				which is a Central statute and the Rules framed thereunder. Goa employment exchange falls under the department 
				of labour and employment and functions as an interface between employers and jobseekers.Registering with a 
				regional employment exchange greatly enhances an unemployed individual's options of getting a job as the exchange 
				proposes a list of potential candidates to employers seeking to fill vacant positions. The Employment Exchanges 
				are rendering free services to employers as well as to job seekers. The Employment Exchange essentially works as 
				a link between the employers and the job seekers. This Directorate is having two Employment Exchanges located at 
				Panaji and Margao respectively. Both these exchanges have been computerized where registration, renewal and 
				submissions are done online.Employment Exchange renders free service. No fee is charged for any service rendered 
				by the Employment Exchange. Employment Exchange does not provide jobs. It helps to sponsor the names of candidates 
				registered against the vacancies notified to the Employment Exchange. The names are sponsored according to the 
                qualification, experience and seniority on the Live Register of the exchanges. 
            </p><br/><br/>
            

            
        </div>
      </div>
    </div>
  <?php $__env->stopSection(); ?>
	
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
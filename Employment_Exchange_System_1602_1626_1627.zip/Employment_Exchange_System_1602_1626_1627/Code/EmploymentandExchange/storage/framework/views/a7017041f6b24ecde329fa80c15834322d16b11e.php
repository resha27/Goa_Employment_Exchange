<html>
	<head>
		<title>View Feedback</title>
		<meta charset="UTF-8" />
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <link rel="stylesheet" href="<?php echo e(asset('css/employment/view.css')); ?>" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
        <link rel="stylesheet" href="../css/AdminLTE.min.css">
        <link rel="stylesheet" href="../css/_all-skins.min.css">
        <link rel="stylesheet" href="../css/custom.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
		
	<body class="hold-transition skin-green sidebar-mini">
        <header class="main-header">
            <a href="index.php" class="logo logo-bg">
                <span class="logo-mini"><b>J</b>P</span>
                <span class="logo-lg"><b>Admin</b> Dashboard</span>
            </a>
            <nav class="navbar navbar-static-top">
                <div class="navbar-custom-menu">
                    <ul class="nav navbar-nav">
                            <li><a href="/admin"><i class="fa fa-arrow-circle-o-right"></i> Logout</a></li>         
                    </ul>
                </div>
            </nav>
        </header>
		<div class="container">
<table>
  <caption>Feedback</caption>
  <thead>
    <tr>
      <th scope="col">Feedback</th>
  
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $feedback; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
               <td><?php echo e($feedback->message); ?></td>
            
               
                </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>         
  </tbody>
</table>
</div>	

 <footer class="main-footer" style="margin-left: 0px;">
            <div class="text-center">
                <strong>Copyright &copy; 2017-2018 <a href="learningfromscratch.online">Employment Exchange</a>.</strong> All rights
            reserved.
            </div>
        </footer>
        <div class="control-sidebar-bg"></div>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script src="../js/adminlte.min.js"></script>	
	</body>
</html>
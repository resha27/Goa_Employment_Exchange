<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateJobseekerdetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('jobseekerdetails', function (Blueprint $table) {
            $table->increments('id');
            $table->string('fullname');
            $table->string('gender');
            $table->string('maritial');
            $table->string('fathername');
            $table->string('dob');
            $table->text('address');
            $table->string('state');
            $table->integer('contact');
            $table->string('qualifications');
            $table->string('fileupload');
            $table->string('hssc');
            $table->string('fileupload2');
            $table->string('graduation');
            $table->string('fileupload3');
            $table->string('postgraduation');
            $table->string('fileupload4');
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('jobseekerdetails');
    }
}

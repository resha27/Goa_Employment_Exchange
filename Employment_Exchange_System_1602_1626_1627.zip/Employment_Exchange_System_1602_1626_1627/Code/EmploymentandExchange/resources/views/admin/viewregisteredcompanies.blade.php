<html>
	<head>
        <meta charset="UTF-8" />
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <link rel="stylesheet" href="{{ asset('css/employment/view.css')}}" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
        <link rel="stylesheet" href="../css/AdminLTE.min.css">
        <link rel="stylesheet" href="../css/_all-skins.min.css">
        <link rel="stylesheet" href="../css/custom.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
        
        <title>Verify Company</title>

    </head>
	<body class="hold-transition skin-green sidebar-mini">
        <header class="main-header">
            <a href="index.php" class="logo logo-bg">
                <span class="logo-mini"><b>J</b>P</span>
                <span class="logo-lg"><b>Admin</b> Dashboard</span>
            </a>
            <nav class="navbar navbar-static-top">
                <div class="navbar-custom-menu">
                    <ul class="nav navbar-nav">
                            <li><a href="/admin"><i class="fa fa-arrow-circle-o-right"></i> Logout</a></li>           
                    </ul>
                </div>
            </nav>
        </header>
   
		<div class="container">
        
        <table>
            <caption>Company List</caption>
            <thead>
                <tr>
                    <th scope="col">UserName</th>
                    <th scope="col">Email</th>
                    <th scope="col">Company</th>
                    <th scope="col">UserType</th>
                    <th scope="col"></th>
                    <th scope="col"></th>
        
                </tr>
            </thead>
            <tbody>
                @foreach($User as $user)
                <tr>
                        <td>{{ $user->name }}</td>
                        <td>{{ $user->email }}</td>
                        <td>{{ $user->company }}</td>
                        <td>{{ $user->usertype }}</td>
                <td class="center"> <a href="{{ url('/admin/verify_companies/'.$user->id) }}" class="btn btn-primary btn-mini">Verify</a></td> 
                <td class="center"> <a href="{{ url('/admin/delete_companies/'.$user->id) }}" class="btn btn-primary btn-mini">Delete</a></td> 
                    </tr>
                 @endforeach        
             </tbody>
        </table>
        </div><br/><br/><br/><br/>	

        <footer class="main-footer" style="margin-left: 0px;">
            <div class="text-center">
                <strong>Copyright &copy; 2017-2018 <a href="learningfromscratch.online">Employment Exchange</a>.</strong> All rights
            reserved.
            </div>
        </footer>
        <div class="control-sidebar-bg"></div>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script src="../js/adminlte.min.js"></script>
	</body>
</html>
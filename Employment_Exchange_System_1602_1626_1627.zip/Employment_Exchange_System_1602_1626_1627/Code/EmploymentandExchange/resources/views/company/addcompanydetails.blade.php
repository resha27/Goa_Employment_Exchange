<!DOCTYPE html>
<html>
	<head>
		<title>Add Details</title>
        <!--<link rel="stylesheet" href="{{ URL::asset('css/addjob.css')}}" />-->
        <link rel="stylesheet"  href="../css/addjob.css"/>
       
	<body>
        <header>
            <div class="head">
                <p>Company Dashboard</p>
            </div>
        </header>
		
        <form method="post" action="{{  url('/company/addcompanydetails')}}">
            <div class="container">
                <div id="title"><h2>ADD COMPANY DETAILS</h2></div>
                {{csrf_field()}}
            
                <div class="left-content"><label for="companyname">Company Name :</label></div>
                <div class="right-content">
                    <input type="text" name="companyname" placeholder="Example. Abc Group" required />
                </div>
            
                <div class="left-content"><label for="organizationtype">Select Organization :</label></div>
                <div class="right-content">
                    <select id="selectid" name="organization" style="width: 150px; height:48px" required >
                        <option value="" disabled selected>Organization Type :</option>
                        <option value="centralgovernment">Central Goverment</option>
                        <option value="stategovernment">State Goverment</option>
                        <option value="private">Private</option>
                        <option value="localbody">Local Body</option>
                    </select>
                </div>
    
                <div class="left-content"><label for="industrytype">Industry Type :</label></div>
                <div class="right-content">
                    <select id="selectid" name="industry" style="width: 150px; height:48px" required >
                        <option value="" disabled selected>Industry Type</option>
                        <option value="agriculture">Agriculture</option>
                        <option value="education">Education</option>
                        <option value="construction">Construction</option>
                        <option value="fishing">Fishing</option>
                        <option value="hotel">Hotel and Restaurent</option>
                        <option value="health">Health and Social Work</option>
                        <option value="other">Local Body</option>
                    </select>
                </div>
    
                <div class="left-content"><label for="websiteurl">Website :</label></div>
                <div class="right-content">
                    <input type="url" id="url" placeholder="websiteurl" name="websiteurl" required />
                </div>
    
                <div class="left-content"><label for="country">Select Country :</label></div>
                <div class="right-content" >
                    <select id="selectid" name="country" style="width: 150px; height:48px" required >
                        <option value="" disabled selected>Country</option>
                        <option value="Afghanistan">Afghanistan</option>
                        <option value="Albania">Albania</option>
                        <option value="Algeria">Algeria</option>
                        <option value="Egypt">Egypt</option>
                        <option value="El Salvador">El Salvador</option>
                        <option value="Equatorial Guinea">Equatorial Guinea</option>
                        <option value="Eritrea">Eritrea</option>
                        <option value="Iceland">Iceland</option>
                        <option value="India">India</option>
                        <option value="Indonesia">Indonesia</option>
                        <option value="Iran">Iran (Islamic Republic of)</option>
                        <option value="Iraq">Iraq</option>
                        <option value="Zimbabwe">Zimbabwe</option>
                    </select>
                </div>
                
                <div class="left-content"><label for="officeaddress">Address :</label></div>
                <div class="right-content">
                    <textarea name="address" id="textarea" placeholder="headoffice address" rows="7" cols="47" required ></textarea>
                </div>
    
                <div class="left-content"><label for="pin">Pin Code :</label></div>
                <div class="right-content">
                    <input type="text" id="text" placeholder="Example. 403005" name="pin" required /> 
                </div>
    
                <div class="left-content"><label for="phone">Phone :</label></div>
                <div class="right-content">
                    <input type="tel" id="text" placeholder="Example. 9405813459" name="phone" pattern="[7-9]{1}[0-9]{9}" style="width: 150px; height:48px" required />  
                </div>
        
                <div id="btn">
                    <button class="button submit">Submit</button>
                    <button class="button reset" value="reset" type="reset">Reset</button>
                </div>
            </div>
        </form>
	</body>
</html>
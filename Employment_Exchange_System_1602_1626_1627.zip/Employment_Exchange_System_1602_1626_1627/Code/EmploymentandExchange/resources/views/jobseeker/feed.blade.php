<!DOCTYPE html>
<html>
	<head>
        <link rel="stylesheet" href="../css/addjob.css"/>

        <title>Feedback</title>
    </head>
	<body class="hold-transition skin-green sidebar-mini">
        <header>
            <div class="head">
                <p>FEEDBACK</p>
                
            </div>
        </header>
			
        <form method="POST" action="{{ url('jobseeker/feed') }}" >
                <div id="title"><h2>Enter Your Feedback</h2></div>
                {{csrf_field()}}

            <!--<div class="left-content"><label for="emailid">Email ID :</label></div>
            <div class="right-content">
                <input type="text" name="email" placeholder="Example. abc@xyz.com" required/>
            </div>-->


            <div class="left-content"><label for="feedback">Enter Your Feedback :</label></div>
            <div class="right-content">
                <textarea name="message" placeholder="Enter your Feedback...." rows="7" cols="47" required /></textarea>
            </div>

            <div id="btn">
                    <button class="button submit">Submit</button>
                    <button class="button reset" value="reset" type="reset">Reset</button>
            </div>  
        </form>
    </div>
        <footer>
            <div class="foot">
                <p>Copyright &copy; Goa Employment Exchange 2018</p>
            </div>
        </footer>
    </body>
</html>
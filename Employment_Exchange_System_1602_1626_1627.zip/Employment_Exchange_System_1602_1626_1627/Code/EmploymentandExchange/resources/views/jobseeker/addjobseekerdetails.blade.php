<!DOCTYPE html>
<html>
	<head>
		<title>Add JobSeeker Details</title>
        <!--<link rel="stylesheet"  href="{{ asset('css/employment/addjob.css')}}"/>-->
        <link rel="stylesheet"  href="../css/addjob.css"/>
	<body>
        <header>
            <div class="head">
                <p>JobSeeker Dashboard</p>
            </div>
        </header>

		<form method="post" action="{{  url('/jobseeker/addjobseekerdetails')}}">
        {{csrf_field()}}
        
        <div class="container">
            <div id="title"><h2>ADD Details</h2></div>

                <div class="left-content"><label for="fullname">Full Name:</label></div>
                    <div class="right-content">
                        <input type="text" name="fullname" placeholder="Example. Ravi Kumar" required/>
                    </div>
                </div>

                <div class="left-content"><label for="gender">Gender :</label></div>
                <div class="right-content">
                    <select id="selectid" name="gender" style="width: 150px; height:48px" required>
                        <option value="" disabled selected></option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                    </select>
                </div>
            </div>

            <div class="left-content"><label for="gender">Maritial Status :</label></div>
                <div class="right-content">
                    <select id="selectid" name="maritial" style="width: 150px; height:48px" required>
                        <option value="" disabled selected></option>
                        <option value="unmarried">Unmarried</option>
                        <option value="married">Married</option>
                        <option value="widow">Widow</option>
                    </select>
                </div>
        <div class="left-content"><label for="fathersName">Father's Name :</label></div>
        <div class="right-content">
            <input type="text" id="text" placeholder="Example. S Kumar" name="fathername" required/>
        </div>

        <div class="left-content"><label for="fathersName">Date of Birth :</label></div>
        <div class="right-content">
            <input type="date" id="text" placeholder="DOB" name="dob" style="width: 150px; height:48px" required/>
        </div>

        <div class="left-content"><label for="gender">Address :</label></div>
        <div class="right-content">
            <textarea name="address" id="textarea" placeholder="Address" rows="7" cols="47" required></textarea>
        </div>

        <div class="left-content"><label for="state">Select State</label></div>
        <div class="right-content">
            <select id="selectid" name="state" style="width: 100px; height:48px" required>
                <option value="" disabled selected>State</option>
                <option value="goa">Goa</option>
                <option value="karnataka">Karnataka</option>
                <option value="ap">Andhra Pradesh</option>
                <option value="assam">Assam</option>
                <option value="bihar">Bihar</option>
                <option value="guj">Gujrat</option>
                <option value="har">Haryana</option>
                <option value="mp">Madhya Pradesh</option>
                <option value="jk">Jammu and Kashmir</option>
            </select>
        </div>
     
            <div class="left-content"><label for="contact">Contact Number :</label></div>
            <div class="right-content">
                <input type="text" id="text" placeholder="Example. 9405813459" pattern="[7-9]{1}[0-9]{9}" name="contact" required/> 
            </div> 

            <div class="left-content"><label for="contact">Educational Qualifications :</label></div>
            <div class="right-content">
                <input type="text" id="text" placeholder="Educational Qualifications" name="qualifications"/>
            </div>  
  
            <div class="left-content"><label for="fileupload">SSC :</label></div>
            <div class="right-content">
                <input type="file" name="fileupload" value="fileupload" id="fileupload" style="width: 200px; height:48px" required> 
            </div>

            <div class="left-content"><label for="fileupload">HSSC :</label></div>
        <div class="right-content">
                <select id="selectid" name="hssc" style="width: 100px; height:48px">
                    <option value="" disabled selected>Stream</option>
                    <option value="arts">Arts</option>
                    <option value="commerce">Commerce</option>
                    <option value="science">Science</option>
                    <option value="vocational">Vocational</option>
                </select>

                
                   
               
                <input type="file"  name="fileupload2" value="fileupload" id="fileupload2" style="width: 200px; height:48px"> 
            </div>

            <div class="left-content"><label for="fileupload">Graduation :</label></div>
            <div class="right-content">
                <select id="selectid" name="graduation" style="width: 100px; height:48px">
                    <option value="" disabled selected>Course</option>
                    <option value="bca">BCA</option>
                    <option value="bsc">BSC</option>
                    <option value="bcom">BCOM</option>
                    <option value="ba">BA</option>
                </select>
                <input type="file"  name="fileupload3" value="fileupload" id="fileupload3" style="width: 200px; height:48px"> 
            </div>

            <div class="left-content"><label for="fileupload">Post-Graduation :</label></div>
            <div class="right-content">
                <select id="selectid" name="postgraduation" style="width: 100px; height:48px">
                    <option value="" disabled selected>Course</option>
                    <option value="mca">MCA</option>
                    <option value="msc">MSC</option>
                    <option value="mcom">MCOM</option>
                    <option value="ma">MA</option>
                </select>
                <input type="file"  name="fileupload4" value="fileupload" id="fileupload4" style="width: 200px; height:48px"> 
            </div>

            <div id="btn">
                <button class="button submit">Submit</button>
                <button class="button reset" value="reset" type="reset">Reset</button>
            </div>
        </div>
    </form>
    <footer>
        <div class="foot">
            <p>Copyright &copy; Goa Employment Exchange 2018</p>
        </div>
    </footer>
    </body>
</html>
<!DOCTYPE html>
<html>
	<head>
		<title>Add JobSeeker Details</title>
        <!--<link rel="stylesheet"  href="{{ asset('css/employment/addjob.css')}}"/>-->
        <link rel="stylesheet"  href="../css/addjob.css"/>
	<body>
        <header>
            <div class="head">
                <p>JobSeeker Dashboard</p>
            </div>
        </header>

		<form method="post" action="{{ url('/jobseeker/edit/'.$jobseekerdetails->id)}}">
        {{csrf_field()}}
        
        <div class="container">
            <div id="title"><h2>Edit Details</h2></div>

              

              


            <div class="left-content"><label for="contact">Educational Qualifications :</label></div>
            <div class="right-content">
                <input type="text" id="text" value="jobseekerdetails->qualifications" placeholder="Educational Qualifications" name="qualifications"/>
            </div>  
  
            <div class="left-content"><label for="fileupload">SSC :</label></div>
            <div class="right-content">
                <input type="file" name="fileupload" value="jobseekerdetails->fileupload" id="fileupload" style="width: 200px; height:48px" required> 
            </div>

            <div class="left-content"><label for="fileupload">HSSC :</label></div>
        <div class="right-content">
                <select id="selectid" name="hssc" style="width: 100px; height:48px">
                    <option value="" disabled selected>Stream</option>
                    <option value="arts">Arts</option>
                    <option value="commerce">Commerce</option>
                    <option value="science">Science</option>
                    <option value="vocational">Vocational</option>
                </select>

                
                   
               
                <input type="file"  name="fileupload2" value="fileupload" id="fileupload2" style="width: 200px; height:48px"> 
            </div>

            <div class="left-content"><label for="fileupload">Graduation :</label></div>
            <div class="right-content">
                <select id="selectid" name="graduation" style="width: 100px; height:48px">
                    <option value="" disabled selected>Course</option>
                    <option value="bca">BCA</option>
                    <option value="bsc">BSC</option>
                    <option value="bcom">BCOM</option>
                    <option value="ba">BA</option>
                </select>
                <input type="file"  name="fileupload3" value="fileupload" id="fileupload3" style="width: 200px; height:48px"> 
            </div>

            <div class="left-content"><label for="fileupload">Post-Graduation :</label></div>
            <div class="right-content">
                <select id="selectid" name="postgraduation" style="width: 100px; height:48px">
                    <option value="" disabled selected>Course</option>
                    <option value="mca">MCA</option>
                    <option value="msc">MSC</option>
                    <option value="mcom">MCOM</option>
                    <option value="ma">MA</option>
                </select>
                <input type="file"  name="fileupload4" value="fileupload" id="fileupload4" style="width: 200px; height:48px"> 
            </div>

            <div id="btn">
                <button class="button submit">Submit</button>
                <button class="button reset" value="reset" type="reset">Reset</button>
            </div>
        </div>
    </form>
    <footer>
        <div class="foot">
            <p>Copyright &copy; Goa Employment Exchange 2018</p>
        </div>
    </footer>
    </body>
</html>
<html>
	<head>
		<title>View Job</title>
		<meta charset="UTF-8" />
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <link rel="stylesheet" href="{{ asset('css/employment/view.css')}}" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
        <link rel="stylesheet" href="../css/AdminLTE.min.css">
        <link rel="stylesheet" href="../css/_all-skins.min.css">
        <link rel="stylesheet" href="../css/custom.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
		
	<body class="hold-transition skin-green sidebar-mini">
        <header class="main-header">
            <a href="index.php" class="logo logo-bg">
                <span class="logo-mini"><b>J</b>P</span>
                <span class="logo-lg"><b>Admin</b> Dashboard</span>
            </a>
            <nav class="navbar navbar-static-top">
                <div class="navbar-custom-menu">
                    <ul class="nav navbar-nav">
                            <li><a href="/jobseeker"><i class="fa fa-arrow-circle-o-right"></i> Logout</a></li>          
                    </ul>
                </div>
            </nav>
        </header>
		<div class="container">
<table>
  <caption>Job List</caption>
  <thead>
    <tr>
      <th scope="col">JobDesignation</th>
      <th scope="col">Minimun Qualification</th>
      <th scope="col">Experience Required</th>
      <th scope="col">Job Details</th>
      <th scope="col">Salary(Rs)</th>
    </tr>
  </thead>
  <tbody>
  @foreach($addjobs as $add)
               <tr>
               <td>{{ $add->jobdesignation }}</td>
               <td>{{ $add->minqual }}</td>
               <td>{{ $add->experience }}</td>
               <td>{{ $add->jobdetails }}</td>
               <td>{{ $add->salary }}</td> 
               
                </tr>
      @endforeach         
  </tbody>
</table>
</div>	

 <footer class="main-footer" style="margin-left: 0px;">
            <div class="text-center">
                <strong>Copyright &copy; 2017-2018 <a href="learningfromscratch.online">Employment Exchange</a>.</strong> All rights
            reserved.
            </div>
        </footer>
        <div class="control-sidebar-bg"></div>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script src="../js/adminlte.min.js"></script>	
	</body>
</html>
<!DOCTYPE html>

<html>
<head>
    <meta charset="utf-8">
    <title>Registration Form</title>

   <!-- <link href="StyleSheet1.css" rel="stylesheet" />-->
    <link rel="stylesheet" href="{{ asset('css/employment/StyleSheet2.css')}}" />

    <link rel="stylesheet" href="{{ asset('css/employment/bootstrap.css')}}" />
    <link rel="stylesheet" href="{{ asset('css/employment/main.css')}}" />
    <link href="css/employment/main.css" rel="stylesheet" />
    <link href="css/employment/bootstrap.min.css" rel="stylesheet" />

    <style>
        body {
            background-image: url('https://www.theclydehotel.com.au/wp-content/uploads/2014/11/bg-pd-2.jpg');
        }
    </style>



</head>
<body>
 
@if(Session::has('flash_message_error'))
            
            <div class="alert alert-success alert-block">
           <button type="button" class="close" data-dismiss="alert">×</button>	
           <strong>{!! session('flash_message_error') !!}</strong>
   </div> 
   @endif
   @if(Session::has('flash_message_success'))
               
               <div class="alert alert-success alert-block">
              <button type="button" class="close" data-dismiss="alert">×</button>	
              <strong>{!! session('flash_message_success') !!}</strong>
      </div> 
      @endif
    <header>
        <!-- Navigation -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
            <div class="container">
                <a class="navbar-brand" href="#">Goa Employment Exchange</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="http://localhost:8000/about">Aboutus</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="http://localhost:8000/contact">Contact</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="http://localhost:8000/jobseeker/jlogin">JobseekerLogin</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="http://localhost:8000/company/clogin">CompanyLogin</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="http://localhost:8000/abc">Register</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    
    <div class="loginBox">
            @if (count($errors)>0)
            @foreach($errors->all() as $error)
            <p class"alert alert-danger">{{$error}}</p>
            @endforeach
           @endif
        @if (session('Status'))
                        
        <p>{{ session('Status') }}</p>
   
@endif
        <h2 style="text-decoration-color:aliceblue;">Registration</h2>
        <form method="POST" action="{{ url('abc') }}" >{{ csrf_field() }}
           
        <p>Full Name</p>
            <input type="text" name="name" value="{{old('name')}}" placeholder="Enter Full Name" required/>
            <p>Email</p>
            <input type="email" name="email" value="{{old('email')}}" placeholder="Enter Email" required/>
            <p>Password</p>
            <input type="password" name="password" placeholder="••••••" required/>
            <p>Confirm Password</p>
            <input type="password" name="password_confirmation" placeholder="••••••" required/>
            <p>User Type</p><br/>
                <select name="usertype">
                    <option value="JobSeeker">JobSeeker</option>
                    <option value="Employer">Employer</option>
                </select><br/><br/><br/>
            <input type="submit" name="submit" value="Submit">

            <br/><br/><br/><br/><br/>
        </form>
    </div>

<footer>
		<div class="footer">
			<p>Copyright @Employment Exchange 2018-2019.</p>
		 </div>
	</footer>


    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>

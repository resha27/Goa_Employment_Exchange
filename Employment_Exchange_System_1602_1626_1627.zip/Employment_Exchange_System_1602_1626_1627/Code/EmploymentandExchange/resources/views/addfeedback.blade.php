<!DOCTYPE html>
	<head>
		<title>Add Feedback</title>
		<link rel="stylesheet" href="{{ asset('css/employment/addjob.css')}}" />
       
	<body>
		<div class="container">
			<br /> <br />
			<form method="post" action="{{  url('/addfeedback')}}">
            {{csrf_field()}}

			<div class="container">


   
    <div class="header">
    
        <h3>ADD FEEDBACK</h3>
        
     
        
    </div>
    
    <div class="sep"></div>

    <div class="inputs">
    
        <input type="text" id="text" placeholder="companyname" name="companyname" required/>
     
<select id="selectid" name="organization">
<option value="" disabled selected>Organization Type</option>
<option value="centralgovernment">Central Goverment</option>
<option value="stategovernment">State Goverment</option>
<option value="private">Private</option>
<option value="localbody">Local Body</option>
</select>

<select id="selectid" name="industry">
<option value="" disabled selected>Industry Type</option>
<option value="agriculture">Agriculture</option>
<option value="education">Education</option>
<option value="construction">Construction</option>
<option value="fishing">Fishing</option>
<option value="hotel">Hotel and Restaurent</option>
<option value="health">Health and Social Work</option>
<option value="other">Local Body</option>
</select>

        <input type="url" id="url" placeholder="websiteurl" name="websiteurl" />
        <select id="selectid" name="country">
        <option value="" disabled selected>Country</option>
        <option value="Afghanistan">Afghanistan</option>
    <option value="Albania">Albania</option>
    <option value="Algeria">Algeria</option>
     <option value="Egypt">Egypt</option>
    <option value="El Salvador">El Salvador</option>
    <option value="Equatorial Guinea">Equatorial Guinea</option>
    <option value="Eritrea">Eritrea</option>
 <option value="Iceland">Iceland</option>
    <option value="India">India</option>
    <option value="Indonesia">Indonesia</option>
    <option value="Iran">Iran (Islamic Republic of)</option>
    <option value="Iraq">Iraq</option>
    <option value="Zimbabwe">Zimbabwe</option>
</select>
        
<textarea name="address" id="textarea" placeholder="headoffice address"></textarea>
     <input type="text" id="text" placeholder="Pin" name="pin" required/>  
     <input type="tel" id="text" placeholder="phone" name="phone" required />  
     
   
  
<button class="button button5">Submit</button>
<button class="button button5" value="reset" type="reset">Reset</button>
    
    </div>

</form>

</div>


				
		
	</body>
</html>
<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('about');
});

Route::match(['get','post'],'admin/', 'AdminController@login');
Route::get('/admin/dashboard', 'AdminController@dashboard');
Route::get('logout', 'AdminController@logout');

Route::get('/admin/viewregisteredcompanies', 'CustomAuthController@viewregisteredcompanies');
Route::match(['get','post'],'/admin/verify_companies/{id}', 'CustomAuthController@verifycompanies');
Route::match(['get','post'],'/admin/delete_companies/{id}', 'CustomAuthController@deletecompanies');


Route::match(['get','post'],'/jobseeker/feed', 'feedbackcontroller@addfeedback');



Route::get('/admin/viewregisteredusers', 'CustomAuthController@viewregisteredusers');
//Route::match(['get','post'],'/admin/verify_companies/{id}', 'CustomAuthController@verifycompanies');
//Route::match(['get','post'],'/admin/delete_companies/{id}', 'CustomAuthController@deletecompanies');
Route::get('/admin/viewfeedback', 'feedbackcontroller@viewfeedback');


Route::get('jobseeker/pdfview',array('as'=>'jobseeker/pdfview','uses'=>'JobseekerController@pdfview'));

Route::get('/company/viewcompanydetails', 'CompanyController@viewcomapanydetails');

Route::match(['get','post'],'/jobseeker/edit/{id}', 'JobseekerController@edit');
//jobseeker controls

Route::match(['get','post'],'/jobseeker', 'JobseekerController@login');
Route::get('/jobseeker/jdashboard', 'JobseekerController@jdashboard');
Route::get('logout', 'JobseekerController@logout');
Route::match(['get','post'],'/jobseeker/addjobseekerdetails', 'JobseekerController@jobseekerdetails');
//Route::match(['get','post'],'/company/addjob', 'addjobscontroller@addjobs');

Route::get('/jobseeker/viewjobs', 'addjobscontroller@viewjobs');

Route::get('/company/generatecard', 'Jobseekerontroller@generatecard');
Route::get('/jobseeker/editdetails', 'JobseekerController@editdetails');
//company controls

Route::match(['get','post'],'/company', 'CompanyController@login');
Route::get('/company/cdashboard', 'CompanyController@cdashboard');
Route::get('logout', 'CompanyController@logout');

//Route::post('/cdashboard', 'CompanyController@addcompanydetails');

Route::match(['get','post'],'/company/addcompanydetails', 'CompanyController@companydetails');
Route::match(['get','post'],'/company/addjob', 'addjobscontroller@addjobs');
Route::get('/company/viewjobseeker', 'JobseekerController@viewjobseeker');




//all links 
//company
Route::get('company/addcompanydetails', function () {
    return view('company/addcompanydetails');
});


Route::get('jobseeker/feed', function () {
    return view('jobseeker/feed');
});


Route::get('company/addjob', function () {
    return view('company/addjob');
});

//jobseeker
Route::get('jobseeker/addjobseekerdetails', function () {
    return view('jobseeker/addjobseekerdetails');
});

//main page
Route::get('/about', function () {
    return view('/about');
});
Route::get('/contact', function () {
    return view('/contact');
});
Route::get('company/clogin', function () {
    return view('company/clogin');
});
Route::get('jobseeker/jlogin', function () {
    return view('jobseeker/jlogin');
});


Route::get('/abc', function () {
    return view('/abc');
});


Route::get('auth/register', function () {
    return view('auth/register');
});



//Route::get('jobseeker/pdfview', function () {
    //return view('jobseeker/pdfview');
//});







//Route::get('/registration/registrationForm', 'AdminController@registrationForm');
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');


Route::get('abc','CustomAuthController@showRegisterForm')->name('abc');
Route::post('abc','CustomAuthController@register');



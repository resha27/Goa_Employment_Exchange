<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class addjobs extends Model
{
    //
}

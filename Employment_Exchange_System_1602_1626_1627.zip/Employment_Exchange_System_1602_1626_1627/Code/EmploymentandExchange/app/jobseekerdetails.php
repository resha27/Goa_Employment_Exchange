<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class jobseekerdetails extends Model
{
    //
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\feedback;
use Session;
use Auth;
use App\user;
class feedbackcontroller extends Controller
{
    public function addfeedback(Request $request)
    {
        if($request->isMethod('post'))
        {
            $data= $request->all();
            $feedback = new feedback;
            $feedback->email = Auth::user()->email;;
            $feedback->message = $data["message"];
            $feedback->save();
            return view('jobseeker.jdashboard')->with(compact('Thank you for your feedback'));
        }
        
}
public function viewfeedback(){
    $feedback = feedback::get();
    //$addjobs = json_decode(json_encode($addjob));
    //echo "<prev>"; print_r($addjobs);die;
    return view('admin.viewfeedback')->with(compact('feedback'));
}

}
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Session;
use App\User;
use DB;
use pdf;
use App\jobseekerdetails;

class JobseekerController extends Controller
{
    public function login(Request $request)
    {
            if($request->isMethod('post')){
                $data = $request->input();
                if(Auth::attempt(['email'=>$data['email'],'password'=>$data['password']])){
                        Session::put('jobseekerSession',$data['email']);
                        return redirect('/jobseeker/jdashboard');
                        //echo $jobseekerSession;
                }else{
                    return redirect('/jobseeker')->with('flash_message_error','Invalid Username or Password');
                    //echo "failed";
                }
                
            }
           return view('jobseeker.jlogin');
    }


    public function jdashboard(){
        if(Session::has('jobseekerSession'))
         {
            
         }else{
             return redirect('/jobseeker')->with('flash_message_error','Please LogIn to Access');
         }
         return view('jobseeker.jdashboard');
     }
 
     public function logout(){
         Session::flush();
         return redirect('/jobseeker')->with('flash_message_success','Logged Out Successfully');
     }


    public function jobseekerdetails(Request $request)
    {
        if($request->isMethod('post'))
        {
            $data= $request->all();
            $jobseekdetails = new jobseekerdetails;
            $jobseekdetails->email = Auth::user()->email;
            $jobseekdetails->fullname = $data["fullname"];
            $jobseekdetails->gender = $data["gender"];
            $jobseekdetails->maritial = $data["maritial"];
            $jobseekdetails->fathername = $data["fathername"];
            $jobseekdetails->dob = $data["dob"];
            $jobseekdetails->address = $data["address"];
            $jobseekdetails->state = $data["state"];
            $jobseekdetails->contact = $data["contact"];
            $jobseekdetails->qualifications = $data["qualifications"];
            $jobseekdetails->fileupload = $data["fileupload"];
            $jobseekdetails->hssc = $data["hssc"];
            $jobseekdetails->fileupload2 = $data["fileupload2"];
            $jobseekdetails->graduation = $data["graduation"];
            $jobseekdetails->fileupload3 = $data["fileupload3"];
            $jobseekdetails->postgraduation = $data["postgraduation"];
            $jobseekdetails->fileupload4 = $data["fileupload4"];
            $jobseekdetails->save();
            return redirect('/jobseeker/jdashboard');
        }
        
    
    return view('jobseeker.jdashboard');
    }

    public function viewjobseeker(){
      
        $jobseekerdetails = jobseekerdetails::get();
        //$addjobs = json_decode(json_encode($addjob));
        //echo "<prev>"; print_r($addjobseekerdetailsjobs);die;
        return view('company.viewjobseeker')->with(compact('jobseekerdetails'));
    }

    public function pdfview(Request $request)
    {
        $jobseekerdetails = DB::table('jobseekerdetails')->where([
            
            ['email', '=', Auth::user()->email],])->get();
             return view('jobseeker.pdfview')->with(compact('jobseekerdetails'));

        if($request->has('download')){
            $pdf = PDF::loadView('jobseeker.pdfview');
            return $pdf->download('jobseeker.pdfview.pdf');
        }


        return view('jobseeker/pdfview');
    }

    public function editdetails(){
      
        $jobseekerdetails = DB::table('jobseekerdetails')->where([
            
            ['email', '=', Auth::user()->email],
        ])->get();
        //$companydetails = json_decode(json_encode($companydetails));
        //echo "<prev>"; print_r($companydetails);die;
        return view('jobseeker.editdetails')->with(compact('jobseekerdetails'));
    }

    public function edit(Request $request,$id = null){
        //echo "test"; die;
        if($request->isMethod('post')){
            $data = $request->all();
            //echo "<prev>"; print_r($data);die;
            jobseekerdetails::where(['id'=>$id])->update(['email'=>$data['email'],'fullname'=>$data['fullname'],'gender'=>$data['gender'],'dob'=>$data['dob'],'contact'=>$data['contact'],'qualifiactions'=>$data['qualifications'],'fileupload'=>$data['fileupload'],'hssc'=>$data['hssc'],'fileupload2'=>$data['fileupload2'],'graduation'=>$data['graduation'],'fileupload3'=>$data['fileupload3'],'postgraduation'=>$data['postgraduation'],'fileupload4'=>$data['fileupload4']
            ]);
            return redirect('/jobseeker/editdetails')->with('flash_message_success','Details Updated Successfully!');     
         }
        $jobseekerdetails=jobseekerdetails::where(['id'=>$id])->get();
     
     
        return view('jobseeker.edit')->with(compact('jobseekerdetails'));
    }

}























   /* public function viewjobs(){
        $joblist = job::get();
        $joblist = json_decode(json_encode($joblist));
        //echo "<prev>"; print_r($categories);die;
        return view('jobseeker.viewjobs')->with(compact('joblist'));
    }*/


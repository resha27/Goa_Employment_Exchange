<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Auth;
use DB;

class CustomAuthController extends Controller
{
    public function showRegisterForm()
    {
        return view('abc');
    }


    public function register(Request $request)
    {
        $this->validation($request);
        $request['password']=bcrypt($request->password);
        User::create($request->all());
        return redirect('/abc')->with('Status','You have successfully registered');

    }


    public function validation($request)
    {
        return $this->validate($request,[
            'name' => 'required|max:255',
            'email' => 'required|email|unique:users|max:255',
            'password' => 'required|confirmed|max:255',
        ]);
    }
    public function viewregisteredcompanies(){
      
        $User = DB::table('users')->where([
            
            ['userType', '=', 'Employer'],
        ])->get();
        //$companydetails = json_decode(json_encode($companydetails));
        //echo "<prev>"; print_r($companydetails);die;
        return view('admin.viewregisteredcompanies')->with(compact('User'));
    }

   public function verifycompanies($id = null){
        if(!empty($id)){
            DB::table('users')
            ->where(['id'=> $id])
            ->update(['company' => 1]);
            return redirect()->back()->with('flash_message_success','Company Verified Sucessfully');  ;
        }
   }

   public function deletecompanies($id = null){
    if(!empty($id)){
        User::where(['id'=>$id])->delete();
        return redirect()->back()->with('flash_message_success','Company Delete Sucessfully');   
    
    }
}
  
public function viewregisteredusers(){
      
    $User = DB::table('users')->where([
        
        ['userType', '=', 'Jobseeker'],
    ])->get();
    //$companydetails = json_decode(json_encode($companydetails));
    //echo "<prev>"; print_r($companydetails);die;
    return view('admin.viewregisteredusers')->with(compact('User'));
}

public function deletejobseekers($id = null){
    if(!empty($id)){
        User::where(['id'=>$id])->delete();
        return redirect()->back()->with('flash_message_success','Jobseeker Delete Sucessfully');   
    
    }
}

}
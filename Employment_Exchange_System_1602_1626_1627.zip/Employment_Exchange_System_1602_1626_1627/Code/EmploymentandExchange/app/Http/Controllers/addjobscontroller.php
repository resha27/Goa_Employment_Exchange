<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\addjobs;
class addjobscontroller extends Controller
{
    public function addjobs(Request $request)
    {
        if($request->isMethod('post'))
        {
            $data= $request->all();
            $job = new addjobs;
            $job->jobdesignation = $data["jobdesignation"];
            $job->minqual = $data["minqual"];
            $job->experience = $data["experience"];
            $job->jobdetails = $data["jobdetails"];
            $job->salary = $data["salary"];
            $job->save();
            return redirect('/company/cdashboard');
        }
        
    
    return view('company.cdashboard');
    }

    public function viewjobs(){
        $addjobs = addjobs::get();
        //$addjobs = json_decode(json_encode($addjob));
        //echo "<prev>"; print_r($addjobs);die;
        return view('jobseeker.viewjobs')->with(compact('addjobs'));
    }
    
}

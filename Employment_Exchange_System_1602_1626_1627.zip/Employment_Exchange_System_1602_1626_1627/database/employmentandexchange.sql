-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2018 at 08:37 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `employmentandexchange`
--

-- --------------------------------------------------------

--
-- Table structure for table `addjobs`
--

CREATE TABLE `addjobs` (
  `id` int(10) UNSIGNED NOT NULL,
  `jobdesignation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `minqual` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `experience` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jobdetails` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `salary` int(11) NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `addjobs`
--

INSERT INTO `addjobs` (`id`, `jobdesignation`, `minqual`, `experience`, `jobdetails`, `salary`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Web Designer', 'bsc computer science', '3 years', 'weqwtrfhgkjk/', 2300, NULL, '2018-05-10 05:56:15', '2018-05-10 05:56:15'),
(2, 'sdfhj', 'asdshh', 'dsfdgfhh', 'saDzxgvjbnk', 23000, NULL, '2018-05-10 05:58:48', '2018-05-10 05:58:48'),
(3, 'coder', 'bsc', '3 years', 'yiltyhugtrfedwas', 45000, NULL, '2018-05-10 06:21:15', '2018-05-10 06:21:15'),
(4, 'e23wtrtyu', 'ewretry', 'dwfgrty', 'sadwegrh', 23000, NULL, '2018-05-11 02:21:56', '2018-05-11 02:21:56'),
(5, 'y6tg4rf', 'ty5gre', 'trgfeds', 'trge', 55555555, NULL, '2018-05-11 02:24:37', '2018-05-11 02:24:37'),
(6, 'Designer', 'bsc computer science', '3', 'good', 30000, NULL, '2018-05-13 07:44:11', '2018-05-13 07:44:11');

-- --------------------------------------------------------

--
-- Table structure for table `companydetails`
--

CREATE TABLE `companydetails` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `companyname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organization` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `industry` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `websiteurl` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pin` int(11) NOT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `companydetails`
--

INSERT INTO `companydetails` (`id`, `email`, `companyname`, `organization`, `industry`, `websiteurl`, `country`, `address`, `pin`, `phone`, `remember_token`, `created_at`, `updated_at`) VALUES
(6, 'shounak@gmail.com', 'asdfgh', 'stategovernment', 'education', 'http://localhost:8000/company/addcompanydetails', 'Albania', 'sadsfdf', 403101, '9637735456', NULL, '2018-05-13 09:51:51', '2018-05-13 09:51:51');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `email`, `message`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'satu@gmail.com', 'asdfvg', NULL, '2018-05-13 22:07:11', '2018-05-13 22:07:11'),
(3, 'shounak@gmail.com', 'asdfvg', NULL, '2018-05-13 22:08:15', '2018-05-13 22:08:15'),
(4, 'resha@gmail.com', 'asdfghgmhgddss', NULL, '2018-05-13 22:10:36', '2018-05-13 22:10:36'),
(9, 'denver@gmail.com', 'qewretryjyghjk', NULL, '2018-05-13 22:41:45', '2018-05-13 22:41:45');

-- --------------------------------------------------------

--
-- Table structure for table `jobseekerdetails`
--

CREATE TABLE `jobseekerdetails` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fullname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `maritial` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fathername` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dob` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qualifications` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileupload` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hssc` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fileupload2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `graduation` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fileupload3` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postgraduation` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fileupload4` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `jobseekerdetails`
--

INSERT INTO `jobseekerdetails` (`id`, `email`, `fullname`, `gender`, `maritial`, `fathername`, `dob`, `address`, `state`, `contact`, `qualifications`, `fileupload`, `hssc`, `fileupload2`, `graduation`, `fileupload3`, `postgraduation`, `fileupload4`, `remember_token`, `created_at`, `updated_at`) VALUES
(30, 'resha@gmail.com', 'fghfgfg', 'male', 'married', 'sdfgh', '2018-05-10', 'gfdsdfghjkljhg', 'ap', '9881663788', 'lkjhgfds', '.jpg', 'arts', NULL, 'bsc', NULL, 'mcom', NULL, NULL, '2018-05-13 13:02:32', '2018-05-13 13:02:32');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_05_07_195122_create_addjob_table', 2),
(4, '2018_05_08_083450_create_addjobseekerdetails_table', 2),
(5, '2018_05_08_095632_create_addcompanydetails_table', 2),
(6, '2018_05_10_101711_create_addjobs_table', 3),
(7, '2018_05_10_102815_create_addjobs_table', 4),
(8, '2018_05_10_171911_create_companydetails_table', 5),
(9, '2018_05_10_180436_create_companydetails_table', 6),
(10, '2018_05_10_182524_create_companydetails_table', 7),
(11, '2018_05_10_183225_create_companydetails_table', 8),
(12, '2018_05_10_184442_create_jobseekerdetails_table', 9),
(13, '2018_05_13_211229_create_feedback_table', 10),
(14, '2018_05_14_033014_create_feedback_table', 11);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin` int(11) NOT NULL DEFAULT '0',
  `jobseeker` int(11) NOT NULL DEFAULT '0',
  `company` int(11) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `usertype` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `admin`, `jobseeker`, `company`, `remember_token`, `created_at`, `updated_at`, `usertype`) VALUES
(1, 'satu', 'satu@gmail.com', '$2y$10$wf8fmex64WZVgTdswIikJuiIrqSZzGs.XRsbvCvnQQjpJV/8a.iZy', 1, 0, 0, '7q1up4b1F7XfvDZNmErIQgTGBAjVLiGhybe2FhWoufgeWF7prr7TO07uRfYy', '2018-05-08 11:58:25', '2018-05-08 11:58:25', ''),
(2, 'denver', 'denver@gmail.com', '$2y$10$Hnog6TyPzZ.VQguIRWbVeuTgCThrVQh4o2nGA5uZSNl5FasFQ.Pxi', 0, 1, 0, '8aBaQZki0UePOkuO20mxBpQTcIe3COUhgYfNov75J7RmKHVqUuNkiSLYXK5g', '2018-05-08 11:59:54', '2018-05-08 11:59:54', ''),
(3, 'shivam', 'shivam@gmail.com', '$2y$10$yGUlS0hf6Mqg/gXxCOEXRepui5YsUdpD756L9y3QEzVFkzQMHnJma', 0, 1, 0, 'BUNu9cbuvqqO6Mev4R7w1iYWYeElcM2iaoLSx7lC8JwJ7Hrl0IENfOvF352v', '2018-05-08 12:02:34', '2018-05-08 12:02:34', ''),
(4, 'shounak', 'shounak@gmail.com', '$2y$10$16bOJkebxFRBDqy2we7ziOEl2FTDwQL.KAVseniubBsxPV6FkACoS', 0, 0, 1, 's5TlwEQDosYN1dvmBLvfE0qX3CKMFlONz6SWgHBirg3bbMXQt6iNez00CUxA', '2018-05-08 12:03:00', '2018-05-08 12:03:00', ''),
(5, 'nikesh', 'nikesh@gmail.com', '$2y$10$fiBS1iHvnFKZTjIgcIFgBefb7Ptl9o4SMbkUizb1w8Jycc..WeV2m', 0, 0, 1, 'RrHUr2s012F94GQCQojW0qoIRKVUU2cNtBGfbwv8KJHeFw773a2iT5ywduC1', '2018-05-08 12:03:34', '2018-05-08 12:03:34', ''),
(6, 'Johann', 'johann@gmail.com', '$2y$10$XXNSOsuC7c4UMlv1G/cYG.qjNix3ZMdXuCoRPgy6DTC86jWlRARGS', 0, 0, 0, 'Z6rX09TQ3dlO5cil8EEIKNkAIRGghjKp2nw7P8IB7idr3s1oO4bJ4QttFZFB', '2018-05-08 23:16:27', '2018-05-08 23:16:27', ''),
(7, 'Riya', 'riya@gmail.com', '$2y$10$YU.Ur0w5455utS.VJ8tGS.ZklM7VcxrcN/AAZOHnqZpljj.7bMDMO', 0, 0, 0, 'hlGWMKhGMWMmd7pzTJyPSJgjOJvB5uDNwTq6BBPvmP4PTmYiPyGeShgujCL4', '2018-05-08 23:21:29', '2018-05-08 23:21:29', ''),
(8, 'Resha', 'resha@gmail.com', '$2y$10$N2Hg2ibDfxgIEODuCLsYpOpseV3JCQ4PSYSgRZiqrbpQlodOCgLxm', 0, 1, 0, NULL, '2018-05-08 23:58:39', '2018-05-08 23:58:39', ''),
(9, 'sabesh', 'sabesh@gmail.com', '$2y$10$tOwH5QNYQgCKpU6juZRMSe11rUYXFvgAjzmrLMg81Zei.jxXc5ikq', 0, 1, 0, NULL, '2018-05-12 11:12:43', '2018-05-12 11:12:43', 'JobSeeker'),
(12, 'rk', 'rk@gmail.com', '$2y$10$PJVj46BU8G5.Uhz2sGzHFea2mdv0.M8vnWLggHqmwEMOdPYbVANa2', 0, 0, 1, NULL, '2018-05-13 00:49:11', '2018-05-13 00:49:11', 'Employer'),
(15, 'veru', 'veru@gmail.com', '$2y$10$R23PrGolhSGZHQVgfpExgOVG7IpJNPT1IniPYyVAdEpvfDwECgLTG', 0, 0, 0, NULL, '2018-05-13 05:36:36', '2018-05-13 05:36:36', 'JobSeeker'),
(18, 'nikhil', 'nikhil@gmail.com', '$2y$10$zdDoLxVZZXDL78C5W9snX.z1rlfml6gK/bhEaL762nLo.KsJJW/nW', 0, 0, 1, NULL, '2018-05-13 22:48:52', '2018-05-13 22:48:52', 'Employer'),
(19, 'mayur', 'mayur@gmail.com', '$2y$10$RkejB1trHTtggQYueUS6ROZVUdVSz1OoKb83OaxXDrzHybw2/AB7e', 0, 0, 1, NULL, '2018-05-13 23:44:19', '2018-05-13 23:44:19', 'Employer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addjobs`
--
ALTER TABLE `addjobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `companydetails`
--
ALTER TABLE `companydetails`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `feedback_email_unique` (`email`);

--
-- Indexes for table `jobseekerdetails`
--
ALTER TABLE `jobseekerdetails`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addjobs`
--
ALTER TABLE `addjobs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `companydetails`
--
ALTER TABLE `companydetails`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `jobseekerdetails`
--
ALTER TABLE `jobseekerdetails`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
